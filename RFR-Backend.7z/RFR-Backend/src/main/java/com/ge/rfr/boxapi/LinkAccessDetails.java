package com.ge.rfr.boxapi;

public class LinkAccessDetails {

    private String access;

    public String getAccess() {
        return access;
    }

    public void setAccess(String access) {
        this.access = access;
    }


}
