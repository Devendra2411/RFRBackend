package com.ge.rfr.boxapi;

public class LinkDetailsWrapper {

    private LinkAccessDetails shared_link;

    public LinkAccessDetails getShared_link() {
        return shared_link;
    }

    public void setShared_link(LinkAccessDetails shared_link) {
        this.shared_link = shared_link;
    }


}
