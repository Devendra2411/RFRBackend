
@TypeDef(
        name = "jsonb-string",
        typeClass = JSONBStringUserType.class
)
package com.ge.rfr.common.hibernate;

import org.hibernate.annotations.TypeDef;