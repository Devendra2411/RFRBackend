package com.ge.rfr.fspevent.model;

import com.ge.rfr.common.model.RfrRegion;

public interface DistinctSiteNames {

    String getSiteName();
}
