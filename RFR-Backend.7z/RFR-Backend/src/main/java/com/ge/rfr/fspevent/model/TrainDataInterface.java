package com.ge.rfr.fspevent.model;

public interface TrainDataInterface {

    String getTrainId();

    int getOutageId();

    String getEquipSerialNumber();
}
