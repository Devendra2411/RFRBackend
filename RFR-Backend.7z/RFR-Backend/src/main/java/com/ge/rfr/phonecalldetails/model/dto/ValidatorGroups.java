package com.ge.rfr.phonecalldetails.model.dto;

public interface ValidatorGroups {
    public interface PhoneCallMinutesValidator {

    }
}
