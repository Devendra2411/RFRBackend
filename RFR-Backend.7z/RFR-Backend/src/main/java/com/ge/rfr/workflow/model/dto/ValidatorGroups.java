package com.ge.rfr.workflow.model.dto;

public interface ValidatorGroups {
	public interface SiteNameValidator{
		
	}
	
	public interface CalencoDocIdValidator{
		
	}
}
