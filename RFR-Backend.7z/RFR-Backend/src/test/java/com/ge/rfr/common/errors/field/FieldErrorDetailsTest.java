package com.ge.rfr.common.errors.field;

/**
 * Tests JSON behavior of the FieldErrorDetails class since it uses a rather complicated class hierarchy mapping.
 */
public class FieldErrorDetailsTest {}